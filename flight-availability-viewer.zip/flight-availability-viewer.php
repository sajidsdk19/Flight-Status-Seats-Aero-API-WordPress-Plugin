<?php
/*
Plugin Name: Flight Availability Viewer
Description: Fetches and displays flight availability using a specified API.
Version: 1.0
Author: Sajid Khan
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Register the admin menu.
add_action('admin_menu', function () {
    add_menu_page(
        'Flight Availability',
        'Flight Availability',
        'manage_options',
        'flight-availability',
        'render_flight_availability_page',
        'dashicons-airplane',
        20
    );
});

// Render the plugin settings page.
function render_flight_availability_page()
{
    ?>
    <div class="wrap">
        <h1>Flight Availability Viewer</h1>
        <form method="post" action="">
            <?php
            if (isset($_POST['fetch_flights'])) {
                $flights = fetch_flight_availability();
                echo '<textarea rows="10" cols="80" readonly>';
                echo esc_html($flights);
                echo '</textarea>';
            }
            ?>
            <p>
                <button type="submit" name="fetch_flights" class="button button-primary">Fetch Flights</button>
            </p>
        </form>
    </div>
    <?php
}

// Fetch flight availability using the API.
function fetch_flight_availability()
{
    // Include Guzzle HTTP client.
    if (!class_exists('\GuzzleHttp\Client')) {
        require_once(plugin_dir_path(__FILE__) . 'vendor/autoload.php');
    }

    $client = new \GuzzleHttp\Client();

    try {
        $response = $client->request('GET', 'https://seats.aero/partnerapi/availability?take=500&skip=0', [
            'headers' => [
                'accept' => 'application/json',
            ],
        ]);

        return $response->getBody();
    } catch (\Exception $e) {
        return 'Error fetching flight data: ' . $e->getMessage();
    }
}
